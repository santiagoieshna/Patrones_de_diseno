package tests;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import modelo.Caja;



class SingletonTest {

	@Test
	void test() {

	}
}
