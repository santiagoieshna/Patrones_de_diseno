package modelo;

public enum TipoPago {
	contado,tarjeta,aplicacion
}
