package factory_santi.factory;

import factory_santi.product.Operacion;
import modelo.TarjetaPass;
import modelo.TipoPago;

public class ConcreteFactoryOperacion implements AbstractFactoryOperacion{
	//Aqui ya estoy en blanco, me tienen loco que cliente esporadico cambie de tipo de pago y que varie tanto los parametros 
	// de constructores...
	@Override
	public Operacion createOperacionEsporadico(OperacionCreator factoryOperacion, TipoPago tipoPago) {
		
		return null;
	}

	@Override
	public Operacion createOperacionHabitual(OperacionCreator factoryOperacion, TarjetaPass tarjeta) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Operacion createOperacionSocio(OperacionCreator factoryOperacion, String nombreYApellidos, float bonficacion,
			String codeApp) {
		// TODO Auto-generated method stub
		return null;
	}

}
