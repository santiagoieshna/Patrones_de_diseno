package patronEquipo;

public interface Subscriber<T> {
	 void update(T context);
}
