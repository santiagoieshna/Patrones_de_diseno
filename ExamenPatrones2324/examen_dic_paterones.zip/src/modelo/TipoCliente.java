package modelo;

public enum TipoCliente {
	esporadico,habitual,asociado;
}
