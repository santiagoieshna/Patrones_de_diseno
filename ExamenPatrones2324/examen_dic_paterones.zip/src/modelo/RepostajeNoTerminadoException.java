package modelo;

public class RepostajeNoTerminadoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RepostajeNoTerminadoException() {
		super("no se puede proseguir la operacion, repostaje no valido");
	}
	
	
	

}
